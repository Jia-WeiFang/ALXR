#pragma once
#ifdef XR_ENABLE_CUDA_INTEROP
#include <cuda_runtime_api.h>
#include <cuda_runtime.h>
#include <cuda_d3d11_interop.h>
#include "WindowsSecurityAttributes.h"
#endif
