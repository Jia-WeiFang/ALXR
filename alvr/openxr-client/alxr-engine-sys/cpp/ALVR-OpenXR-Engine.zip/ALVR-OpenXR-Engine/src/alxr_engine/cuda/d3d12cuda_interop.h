#pragma once
#ifdef XR_ENABLE_CUDA_INTEROP
#include <cuda_runtime_api.h>
#include <cuda_runtime.h>

#include <cstring>
#include <atomic>
#include "WindowsSecurityAttributes.h"
#endif
